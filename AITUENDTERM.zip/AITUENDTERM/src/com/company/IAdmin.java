package com.company;

public interface IAdmin {

    public void addClient();

    public void deleteClient();

    public void getClients();


}
